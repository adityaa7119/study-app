// app/api/ai-tutor/route.ts
import { NextRequest, NextResponse } from "next/server";
import { GoogleGenAI } from "@google/genai";
import { createServerSupabaseClient } from "@/lib/supabase/server";

const genai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

const SYSTEM_INSTRUCTION = `You are StudyBot, an expert AI tutor specializing in competitive exam preparation (JEE, NEET, UPSC, CAT, GATE). 

Your personality:
- Friendly, encouraging, and patient
- Use simple language to explain complex concepts
- Provide step-by-step solutions
- Include relevant formulas with LaTeX notation
- End responses with a motivational nudge when appropriate

Your capabilities:
- Explain any Physics, Chemistry, Mathematics, Biology concept clearly
- Create practice questions with detailed solutions
- List key formulas for a topic
- Break down problem-solving strategies

Format your responses using markdown for readability. Keep responses concise but complete. When showing formulas, use LaTeX ($ for inline, $$ for block equations).`;

export async function POST(request: NextRequest) {
  try {
    // Verify authentication
    const supabase = await createServerSupabaseClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { message, previousInteractionId } = body as {
      message: string;
      previousInteractionId?: string;
    };

    if (!message?.trim()) {
      return NextResponse.json({ error: "Message is required" }, { status: 400 });
    }

    // Use the Interactions API for stateful conversation
    const interaction = await genai.interactions.create({
      model: "gemini-3.8-flash",
      system_instruction: SYSTEM_INSTRUCTION,
      input: message.trim(),
      ...(previousInteractionId ? { previous_interaction_id: previousInteractionId } : {}),
      store: true,
    });

    const responseText = interaction.output_text;
    if (!responseText) {
      return NextResponse.json({ error: "Empty response from AI" }, { status: 500 });
    }

    return NextResponse.json({
      reply: responseText,
      interactionId: interaction.id,
    });
  } catch (err) {
    console.error("[AI Tutor] Error:", err);
    const message = err instanceof Error ? err.message : "AI service error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
